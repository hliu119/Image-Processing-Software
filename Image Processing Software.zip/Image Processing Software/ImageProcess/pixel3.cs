﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 计算图像
{
    public partial class pixel3 : Form
    {
        public pixel3()
        {
            InitializeComponent();
        }

        private void pixel3_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
