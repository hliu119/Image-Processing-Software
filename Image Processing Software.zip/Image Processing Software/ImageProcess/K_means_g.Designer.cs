﻿namespace 计算图像
{
    partial class K_means_g
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.g_tB1 = new System.Windows.Forms.TextBox();
            this.g_p2 = new System.Windows.Forms.Panel();
            this.g_cB1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.g_cB2 = new System.Windows.Forms.ComboBox();
            this.g_cB3 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.g_p1 = new System.Windows.Forms.Panel();
            this.g_cB4 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.g_rb2 = new System.Windows.Forms.RadioButton();
            this.g_rb1 = new System.Windows.Forms.RadioButton();
            this.g_b_Kmean = new System.Windows.Forms.Button();
            this.g_cB_kindnum = new System.Windows.Forms.ComboBox();
            this.g_b_showcolor = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.g_p2.SuspendLayout();
            this.g_p1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(279, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 50;
            this.label6.Text = "阈值：";
            // 
            // g_tB1
            // 
            this.g_tB1.Location = new System.Drawing.Point(349, 87);
            this.g_tB1.Name = "g_tB1";
            this.g_tB1.Size = new System.Drawing.Size(81, 21);
            this.g_tB1.TabIndex = 49;
            this.g_tB1.Text = "1";
            // 
            // g_p2
            // 
            this.g_p2.Controls.Add(this.g_cB1);
            this.g_p2.Controls.Add(this.label2);
            this.g_p2.Controls.Add(this.label3);
            this.g_p2.Controls.Add(this.g_cB2);
            this.g_p2.Controls.Add(this.g_cB3);
            this.g_p2.Controls.Add(this.label1);
            this.g_p2.Location = new System.Drawing.Point(11, 18);
            this.g_p2.Name = "g_p2";
            this.g_p2.Size = new System.Drawing.Size(154, 139);
            this.g_p2.TabIndex = 48;
            this.g_p2.Visible = false;
            // 
            // g_cB1
            // 
            this.g_cB1.FormattingEnabled = true;
            this.g_cB1.Location = new System.Drawing.Point(67, 26);
            this.g_cB1.Name = "g_cB1";
            this.g_cB1.Size = new System.Drawing.Size(59, 20);
            this.g_cB1.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 24;
            this.label2.Text = "波段2：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 25;
            this.label3.Text = "波段3：";
            // 
            // g_cB2
            // 
            this.g_cB2.FormattingEnabled = true;
            this.g_cB2.Location = new System.Drawing.Point(67, 60);
            this.g_cB2.Name = "g_cB2";
            this.g_cB2.Size = new System.Drawing.Size(59, 20);
            this.g_cB2.TabIndex = 27;
            // 
            // g_cB3
            // 
            this.g_cB3.FormattingEnabled = true;
            this.g_cB3.Location = new System.Drawing.Point(67, 94);
            this.g_cB3.Name = "g_cB3";
            this.g_cB3.Size = new System.Drawing.Size(59, 20);
            this.g_cB3.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 23;
            this.label1.Text = "波段1：";
            // 
            // g_p1
            // 
            this.g_p1.Controls.Add(this.g_cB4);
            this.g_p1.Controls.Add(this.label5);
            this.g_p1.Location = new System.Drawing.Point(3, 15);
            this.g_p1.Name = "g_p1";
            this.g_p1.Size = new System.Drawing.Size(162, 130);
            this.g_p1.TabIndex = 47;
            // 
            // g_cB4
            // 
            this.g_cB4.FormattingEnabled = true;
            this.g_cB4.Location = new System.Drawing.Point(68, 54);
            this.g_cB4.Name = "g_cB4";
            this.g_cB4.Size = new System.Drawing.Size(72, 20);
            this.g_cB4.TabIndex = 33;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 34;
            this.label5.Text = "波段：";
            // 
            // g_rb2
            // 
            this.g_rb2.AutoSize = true;
            this.g_rb2.Location = new System.Drawing.Point(127, 51);
            this.g_rb2.Name = "g_rb2";
            this.g_rb2.Size = new System.Drawing.Size(59, 16);
            this.g_rb2.TabIndex = 46;
            this.g_rb2.Text = "多波段";
            this.g_rb2.UseVisualStyleBackColor = true;
            // 
            // g_rb1
            // 
            this.g_rb1.AutoSize = true;
            this.g_rb1.Checked = true;
            this.g_rb1.Location = new System.Drawing.Point(26, 51);
            this.g_rb1.Name = "g_rb1";
            this.g_rb1.Size = new System.Drawing.Size(59, 16);
            this.g_rb1.TabIndex = 45;
            this.g_rb1.TabStop = true;
            this.g_rb1.Text = "单波段";
            this.g_rb1.UseVisualStyleBackColor = true;
            this.g_rb1.CheckedChanged += new System.EventHandler(this.g_rb1_CheckedChanged);
            // 
            // g_b_Kmean
            // 
            this.g_b_Kmean.Location = new System.Drawing.Point(331, 131);
            this.g_b_Kmean.Name = "g_b_Kmean";
            this.g_b_Kmean.Size = new System.Drawing.Size(75, 23);
            this.g_b_Kmean.TabIndex = 44;
            this.g_b_Kmean.Text = "分类计算";
            this.g_b_Kmean.UseVisualStyleBackColor = true;
            this.g_b_Kmean.Click += new System.EventHandler(this.g_b_Kmean_Click);
            // 
            // g_cB_kindnum
            // 
            this.g_cB_kindnum.FormattingEnabled = true;
            this.g_cB_kindnum.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.g_cB_kindnum.Location = new System.Drawing.Point(349, 51);
            this.g_cB_kindnum.Name = "g_cB_kindnum";
            this.g_cB_kindnum.Size = new System.Drawing.Size(81, 20);
            this.g_cB_kindnum.TabIndex = 43;
            // 
            // g_b_showcolor
            // 
            this.g_b_showcolor.Location = new System.Drawing.Point(53, 251);
            this.g_b_showcolor.Name = "g_b_showcolor";
            this.g_b_showcolor.Size = new System.Drawing.Size(94, 23);
            this.g_b_showcolor.TabIndex = 41;
            this.g_b_showcolor.Text = "显示原图像";
            this.g_b_showcolor.UseVisualStyleBackColor = true;
            this.g_b_showcolor.Click += new System.EventHandler(this.g_b_showcolor_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(279, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 42;
            this.label4.Text = "类别数：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(22, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 51;
            this.label7.Text = "选择数据：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.g_p1);
            this.groupBox1.Controls.Add(this.g_p2);
            this.groupBox1.Location = new System.Drawing.Point(20, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(172, 163);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(253, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 20);
            this.label8.TabIndex = 53;
            this.label8.Text = "分类设置：";
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(229, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(1, 274);
            this.label9.TabIndex = 54;
            this.label9.Text = "label9";
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Location = new System.Drawing.Point(229, 168);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(261, 1);
            this.label10.TabIndex = 55;
            this.label10.Text = "label10";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(257, 209);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(217, 83);
            this.textBox1.TabIndex = 56;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(253, 180);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 20);
            this.label11.TabIndex = 57;
            this.label11.Text = "分类结果：";
            // 
            // K_means_g
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 316);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.g_tB1);
            this.Controls.Add(this.g_rb2);
            this.Controls.Add(this.g_rb1);
            this.Controls.Add(this.g_b_Kmean);
            this.Controls.Add(this.g_cB_kindnum);
            this.Controls.Add(this.g_b_showcolor);
            this.Controls.Add(this.label4);
            this.Name = "K_means_g";
            this.Text = "K-Means";
            this.Load += new System.EventHandler(this.K_means_g_Load);
            this.g_p2.ResumeLayout(false);
            this.g_p2.PerformLayout();
            this.g_p1.ResumeLayout(false);
            this.g_p1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox g_tB1;
        private System.Windows.Forms.Panel g_p2;
        private System.Windows.Forms.ComboBox g_cB1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox g_cB2;
        private System.Windows.Forms.ComboBox g_cB3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel g_p1;
        private System.Windows.Forms.ComboBox g_cB4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton g_rb2;
        private System.Windows.Forms.RadioButton g_rb1;
        private System.Windows.Forms.Button g_b_Kmean;
        private System.Windows.Forms.ComboBox g_cB_kindnum;
        private System.Windows.Forms.Button g_b_showcolor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
    }
}